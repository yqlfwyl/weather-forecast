# flutter_weather

Flutter练习项目，效果图如下：

![首页](https://img-blog.csdnimg.cn/20190731135413932.gif)
![今日热点](https://img-blog.csdnimg.cn/2019073113440648.gif)
![搜索](https://img-blog.csdnimg.cn/20190805134252293.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NqZGpkamRqYWhk,size_16,color_FFFFFF,t_70)
![选择城市](https://img-blog.csdnimg.cn/20190805134425416.jpg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3NqZGpkamRqYWhk,size_16,color_FFFFFF,t_70)

接口使用的是急速数据的接口。新闻每天100次限制，如果不够的话你可以自己去申请一个Key，不需要身份证就可以。


### [首页实现](https://blog.csdn.net/sjdjdjdjahd/article/details/97916262)

### [今日热点实现](https://blog.csdn.net/sjdjdjdjahd/article/details/97955932)
