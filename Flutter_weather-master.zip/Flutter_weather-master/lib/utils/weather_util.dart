import 'dart:ui' as ui;
import 'dart:async';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter_weather/model/weather_bean.dart';

class WeatherIconUtil{

  static String getWeatherIconAssetsPath(String img){
    return "assets/images/$img.png";
  }




}