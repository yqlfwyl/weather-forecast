class TitleBean{

}